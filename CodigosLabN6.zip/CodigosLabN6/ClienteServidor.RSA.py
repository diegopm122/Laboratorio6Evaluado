#Jorge Arenas
#Diego Palma


from socket import *
from random import randint
import Crypto
from Crypto.PublicKey import RSA
from Crypto import Random
import ast


################SERVIDOR################################


direccionServidor= "localhost"
puertoServidor= 9099

#generamos un nuevo socket
socketServidor= socket(AF_INET, SOCK_STREAM)
#establecemos la conexion
socketServidor.bind( ( direccionServidor, puertoServidor))
socketServidor.listen()

while True:
    #establecemos la conexion
    socketConexion, addr = socketServidor.accept()
    print("Conectado con un cliente", addr)
    while True:
        #recibimos el mensaje del cliente
        mensajeRecibido= socketConexion.recv(4096).decode()
        print(mensajeRecibido)

        if mensajeRecibido== "Adios":
            break
        #mandamos mensaje al cliente
        socketConexion.send(input().encode())

    print("Descoonectado el cliente", addr)
    #cerramos conexion
    socketConexion.close()


###################CLIENTE########################

IPServidor= "localhost"
puertoServidor= 9099
socketCliente= socket(AF_INET, SOCK_STREAM)
socketCliente.connect((IPServidor, puertoServidor))

while True:

    #escribimos el mensaje
    mensaje= input()
    if mensaje !="adios":

        #enciamos mensaje
        socketCliente.send(mensaje.encode())
        #recibimos mensaje
        respuesta= socketCliente.recv(4096).decode()
        print(respuesta)

    else:
        socketCliente.send(mensaje.encode())
        #cerramos socket
        socketCliente.close()
        sys.exit()





#######################RSA#######################################

generador_random = Random.new().read
key = RSA.generate(1024, generador_random) #generar clave privada

publickey = key.publickey() #se exporta la clave para intercambiar

encrypted = publickey.encrypt('cifrar este mensaje', 32)
#el mensaje para cifrar esta parte es en la línea de arriba 'cifrar este mensaje'

print('enciptar mensaje:', encrypted) #texto cifrado 
f = open ('mensajeentrada.txt', 'w')
f.write(str(encrypted)) #escribir el texto cifrado en el archivo
f.close()

#código descifrado 

f = open('mensajerecibido.txt', 'r')
mensaje = f.read()


decrypted = key.decrypt(ast.literal_eval(str(encrypted)))

print('desencriptar', decrypted)

f = open ('mensajerecibido.txt', 'w')
f.write(str(mensaje))
f.write(str(decrypted))
f=open('mensajerecibido.txt','w')
f.close()
