#Jorge Arenas
#Diego Palma


from Crypto import Random
from Crypto.Random import random
from Crypto.PublicKey import ElGamal
from Crypto.Util.number import GCD
from socket import *
import sys
from random import randint




################SERVIDOR################################


direccionServidor= "localhost"
puertoServidor= 9099

#generamos un nuevo socket
socketServidor= socket(AF_INET, SOCK_STREAM)
#establecemos la conexion
socketServidor.bind( ( direccionServidor, puertoServidor))
socketServidor.listen()

while True:
    #establecemos la conexion
    socketConexion, addr = socketServidor.accept()
    print("Conectado con un cliente", addr)
    while True:
        #recibimos el mensaje del cliente
        mensajeRecibido= socketConexion.recv(4096).decode()
        print(mensajeRecibido)

        if mensajeRecibido== "Adios":
            break
        #mandamos mensaje al cliente
        socketConexion.send(input().encode())

    print("Descoonectado el cliente", addr)
    #cerramos conexion
    socketConexion.close()


###################CLIENTE########################

IPServidor= "localhost"
puertoServidor= 9099
socketCliente= socket(AF_INET, SOCK_STREAM)
socketCliente.connect((IPServidor, puertoServidor))

while True:

    #escribimos el mensaje
    mensaje= input()
    if mensaje !="adios":

        #enciamos mensaje
        socketCliente.send(mensaje.encode())
        #recibimos mensaje
        respuesta= socketCliente.recv(4096).decode()
        print(respuesta)

    else:
        socketCliente.send(mensaje.encode())
        #cerramos socket
        socketCliente.close()
        sys.exit()


##################El_Gammal####################################

from Crypto import Random
from Crypto.Random import random
from Crypto.PublicKey import ElGamal
from Crypto.Util.number import GCD


message = "Hola amigo"

key = ElGamal.generate(1024, Random.new().read)

while 1:
    k = random.StrongRandom().randint(1, key.p - 1)

    if GCD(k, key.p - 1) == 1:
        break


h = key.encrypt(message, k)
f = open ('mensajeentrada.txt', 'k')
f.close()



d = key.decrypt(h)
f = open ('mensajerecibido.txt', 'h')
f.close()
print(d)

        
